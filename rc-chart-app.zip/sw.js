// RC Live Chart service worker: keeps the app shell available and lets Chrome offer "Install app"
const VER='rc-chart-v3', SHELL=['./','index.html','manifest.webmanifest','icon-192.png','icon-512.png'];
self.addEventListener('install',e=>{ e.waitUntil(caches.open(VER).then(c=>c.addAll(SHELL)).then(()=>self.skipWaiting())); });
self.addEventListener('activate',e=>{ e.waitUntil(caches.keys().then(ks=>Promise.all(ks.filter(k=>k!==VER).map(k=>caches.delete(k)))).then(()=>self.clients.claim())); });
self.addEventListener('fetch',e=>{
  const r=e.request, u=new URL(r.url);
  if(r.method!=='GET') return;
  if(u.hostname.endsWith('binance.com')||u.hostname.endsWith('coingecko.com')) return;       // live market data always goes to the network
  if(r.mode==='navigate'){                                                                     // page: newest version first, cached copy if offline
    e.respondWith(fetch(r).then(res=>{ const cp=res.clone(); caches.open(VER).then(c=>c.put('index.html',cp)); return res; }).catch(()=>caches.match('index.html')));
    return; }
  e.respondWith(caches.match(r).then(hit=>hit||fetch(r).then(res=>{                           // files + chart library: cache after first use
    if(res.ok&&(u.origin===location.origin||u.hostname==='cdnjs.cloudflare.com'||u.hostname==='cdn.jsdelivr.net'||u.hostname==='unpkg.com')){ const cp=res.clone(); caches.open(VER).then(c=>c.put(r,cp)); }
    return res; })));
});
